export interface UserI {
  id?: number;
  email?: string;
  username?: string;
  password?: string;
}