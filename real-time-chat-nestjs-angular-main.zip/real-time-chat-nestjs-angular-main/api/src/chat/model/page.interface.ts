export interface PageI {
  page: number;
  limit: number;
}