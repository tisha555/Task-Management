## Open Todos that could be implemented in coming versions

- Create Chatroom, don't select own user
- add logout
- Infinite Scrolling for Chatroom: Messages
- Infinite Scrolling for Rooms
- Frontend Store Management
- Display newest Message in the Rooms List also
- Refactor Styling
- Responsiveness?
- Search for Rooms
- Online List of users
- ...